<?php
require 'vendor/autoload.php';

use Dompdf\Dompdf;
$dompdf = new Dompdf();

$html = <<<'ENDHTML'
<html>
 <body>
  <h1>Hello Dompdf</h1>
 </body>
</html>
ENDHTML;

$dompdf->load_html($html);
$dompdf->render();

$dompdf->stream("hello.pdf");

?>
hello
